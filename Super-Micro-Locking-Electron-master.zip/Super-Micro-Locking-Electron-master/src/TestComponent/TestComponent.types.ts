export interface TestComponentProps {
  theme: "primary" | "secondary";
}
